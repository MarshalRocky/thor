# Hitsuki Cache

This folder is used to store Hitsuki cache